import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';

import { ModalController} from '@ionic/angular';

@Component({
  selector: 'app-my-modal',
  templateUrl: './my-modal.page.html',
  styleUrls: ['./my-modal.page.scss'],
})
export class MyModalPage implements OnInit {
  myForm: FormGroup;
  submitted = false;
  // eslint-disable-next-line @typescript-eslint/no-inferrable-types
  defaultDate = "";
  isenabled: boolean = false;

  data: string[] = [];
  

  constructor(public modalCtrl: ModalController,private route: ActivatedRoute,
    private router: Router,
    public formBuilder: FormBuilder) {}  
  
  ngOnInit() {  
    this.myForm = this.formBuilder.group({
      name: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.pattern('[a-zA-Z ]*'),
        ],
      ],
      subname: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.pattern('[a-zA-Z ]*'),
        ],
      ],
      dob: ['', [Validators.required]],
      
    });
  }  
// eslint-disable-next-line @typescript-eslint/member-ordering
get errorCtr() {
  return this.myForm.controls;
}

getDate(value1) {
  // eslint-disable-next-line prefer-const
  let date = new Date(value1.target.value).toISOString().substring(0, 10);
  this.myForm.get('dob').setValue(date, {
    onlyself: true,
  });
}

clicked(item){

  console.log('Data',this.data);
  this.data.push(item)
}

async onSubmit() {
  this.submitted = true;

  if (!this.myForm.valid) {
    console.log('All Fields are  required');
    return false;
  } else {
    // const user = 'hello';
    // console.log('user',user);
    // console.log('USER',this.user);

    // eslint-disable-next-line prefer-const
    let navigationExtras: NavigationExtras = {
      queryParams: {
        special: JSON.stringify(this.myForm.value)
      }
    };
    console.log(this.myForm.value);
    this.router.navigate(['notes'], navigationExtras);
    await this.modalCtrl.dismiss();
  }
}
  
  async closeModal() {
    await this.modalCtrl.dismiss();
  }
}
