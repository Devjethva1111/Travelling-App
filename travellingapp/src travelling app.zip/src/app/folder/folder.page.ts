import { ContactlistService } from './../services/contactlist.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-folder',
  templateUrl: './folder.page.html',
  styleUrls: ['./folder.page.scss'],
})
export class FolderPage implements OnInit {
  public folder: string;

  films: Observable<any>;

  constructor(private activatedRoute: ActivatedRoute, private movieService: ContactlistService,
     public httpClient: HttpClient) { 

    this.films = this.httpClient.get('https://reqres.in/api/users?page=2');
    this.films
    .subscribe(data => {
      console.log('my data: ', data);
    })
  }

  ngOnInit() {
    this.folder = this.activatedRoute.snapshot.paramMap.get('id');

  }

}


