import { ImagePicker } from '@awesome-cordova-plugins/image-picker/ngx';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.page.html',
  styleUrls: ['./gallery.page.scss'],
})
export class GalleryPage implements OnInit {

  
  imageObj: any;
  options: any;

  constructor(private imagePicker: ImagePicker) { }

  ngOnInit() {
  }

  chooseImage() {
    this.options = {
      width: 220,
      quality: 32,
      outputType: 1
    };
    
    this.imageObj = [];

    this.imagePicker.getPictures(this.options).then((res) => {
      for (var i = 0; i < res.length; i++) {
        this.imageObj.push('data:image/jpeg;base64,' + res[i]);
      }
    }, (error) => {
      alert(error);
    });
  }


}
